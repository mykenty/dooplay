<?php


if($widgets = dynamic_sidebar('widgets-home')) { $widgets; } else { __d('No content'); } ?>